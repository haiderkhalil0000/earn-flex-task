import { useEffect, useState, useRef } from "react";
import "./App.css";
import MapComponent from "./components/MapComponent";
import { getEmployees } from "./service";
import { filterLocation } from "./utils";
import ToastNotification from "./components/ToastNotification";
import { Box, Typography, Tabs, Tab, TextField, Paper } from "@mui/material";
import { Grid } from "@mui/material";
import { toast } from "react-toastify";
import { columns } from "./constant";
import Loader from "./components/Loader";
import TableComponent from "./components/TableComponent";
import TableViewIcon from "@mui/icons-material/TableView";
import MapIcon from "@mui/icons-material/Map";
import PersonAddIcon from "@mui/icons-material/PersonAdd";

function App() {
  const [employees, setEmployees] = useState([]);
  const [employeesLocation, setEmployeesLocation] = useState([]);
  const [isLoading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState("table");
  const [contentHeight, setContentHeight] = useState("calc(100vh - 200px)");
  const effectRan = useRef(false);

  useEffect(() => {
    const updateContentHeight = () => {
      const headerHeight = document.querySelector("h1")?.offsetHeight || 48;
      const tabsHeight =
        document.querySelector(".MuiTabs-root")?.offsetHeight || 48;
      const padding = 40;
      const newHeight = `calc(100vh - ${
        headerHeight + tabsHeight + padding
      }px)`;
      setContentHeight(newHeight);
    };

    updateContentHeight();
    window.addEventListener("resize", updateContentHeight);

    return () => window.removeEventListener("resize", updateContentHeight);
  }, []);

  const getEmployeesData = async () => {
    try {
      setLoading(true);
      const data = await getEmployees();
      setEmployees(data);
      const locations = filterLocation(data);
      console.log(locations);
      setEmployeesLocation(locations);
      toast.success("Data loaded successfully!");
    } catch (error) {
      toast.error("Failed to fetch employees");
      console.error("Error fetching employees:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (effectRan.current === false) {
      getEmployeesData();
      effectRan.current = true;
    }
  }, []);

  const handleTabChange = (event, newValue) => {
    setViewMode(newValue);
  };

const renderContent = () => {
  if (isLoading) {
    return <Loader />;
  }

  if (employees.length === 0) {
    return (
      <Typography variant="h6" textAlign="center">
        No Data Found
      </Typography>
    );
  }

  switch (viewMode) {
    case "table":
      return (
        <Paper
          elevation={1}
          sx={{
            borderRadius: 2,
            overflow: "hidden",
            height: contentHeight,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Box sx={{ flexGrow: 1, overflow: "auto" }}>
            <TableComponent data={employees} columns={columns} />
          </Box>
        </Paper>
      );
    case "map":
      return (
        <Box
          sx={{ height: contentHeight, borderRadius: 2, overflow: "hidden"}}
        >
          <MapComponent
            locations={employeesLocation}
          />
        </Box>
      );
    case "add":
      return (
        <Paper
          elevation={1}
          sx={{
            p: 3,
            borderRadius: 2,
            height: contentHeight,
            overflow: "auto",
          }}
        >
          <Typography variant="h6" textAlign="center">
            Add Employee Form will be here
          </Typography>
        </Paper>
      );
    default:
      return <TableComponent data={employees} columns={columns} />;
  }
};


  return (
    <>
      <ToastNotification />
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          minHeight: "100vh",
          padding: { xs: 2, sm: 3, md: 5 },
        }}
      >
        <Grid
          container
          spacing={2}
          sx={{
            maxWidth: "1200px",
            margin: "0 auto",
            width: "100%",
          }}
        >
          <Grid item xs={12}>
            <Tabs
              value={viewMode}
              onChange={handleTabChange}
              aria-label="View Mode Tabs"
              variant="fullWidth"
              sx={{
                "& .MuiTab-root": {
                  textTransform: "none",
                  fontSize: "1rem",
                  fontWeight: 500,
                },
                mb: 2,
              }}
            >
              <Tab
                value="table"
                label="EMPLOYEES TABLE"
                icon={<TableViewIcon />}
                iconPosition="start"
              />
              <Tab
                value="map"
                label="MAP VIEW"
                icon={<MapIcon />}
                iconPosition="start"
              />
              <Tab
                value="add"
                label="ADD EMPLOYEE"
                icon={<PersonAddIcon />}
                iconPosition="start"
              />
            </Tabs>
            {renderContent()}
          </Grid>
        </Grid>
      </Box>
    </>
  );
}

export default App;

import axios from "axios";

const getActivationCode = async () => {
  const response = await axios.post(
    "https://api.findofficers.com/hiring_test/get_activation_code"
  );

  if (response.status === 200) {
    return response?.data?.activationCode;
  } else {
    throw new Error("Failed to fetch activation code");
  }
};

export const getEmployees = async () => {
  const activationCode = await getActivationCode();
  const response = await axios.post(
    "https://api.findofficers.com/hiring_test/get_all_employee",
    {
        activationCode: activationCode,
    }
  );
  if (response.status === 200) {
    return response.data;
  } else {
    throw new Error("Failed to fetch employees");
  }
};
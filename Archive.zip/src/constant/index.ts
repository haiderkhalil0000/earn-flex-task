export const columns = [
    { Header: "ID", accessor: "Hiring_TestID" },
    { Header: "First Name", accessor: "firstName" },
    { Header: "Last Name", accessor: "lastName" },
    { Header: "Email", accessor: "email" },
    { Header: "City", accessor: "city" },
    { Header: "Country", accessor: "country" },
    { Header: "Phone Number", accessor: "phoneNumber" },
    { Header: "Latitude", accessor: "latitude" },
    { Header: "Longitude", accessor: "longitude" },
    { Header: "Created At", accessor: "createdAt" },
  ];